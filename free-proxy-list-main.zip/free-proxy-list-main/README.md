<p align="center">
  <a href="https://proxifly.dev"><img src="https://cdn.itwcreativeworks.com/assets/proxifly/images/logo/proxifly-brandmark-black-x.svg" width="100px"></a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Updated_Every_5_Minutes-passing-success">
  <br>
  <a href="https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/all/data.txt"><img src="https://img.shields.io/badge/all-11386-blue"></a>
  <a href="https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.txt"><img src="https://img.shields.io/badge/http-5163-blue"></a>
  <a href="https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/https/data.txt"><img src="https://img.shields.io/badge/https-874-blue"></a>
  <a href="https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks4/data.txt"><img src="https://img.shields.io/badge/socks4-500-blue"></a>
  <a href="https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.txt"><img src="https://img.shields.io/badge/socks5-4849-blue"></a>
  <br>
  <!-- <img src="https://img.shields.io/librariesio/release/npm/node-powertools.svg"> -->
  <!-- <img src="https://img.shields.io/bundlephobia/min/node-powertools.svg"> -->
  <!-- <img src="https://img.shields.io/codeclimate/maintainability-percentage/proxifly/free-proxy-list.svg"> -->
  <!-- <img src="https://img.shields.io/npm/dm/node-powertools.svg"> -->
  <!-- <img src="https://img.shields.io/node/v/node-powertools.svg"> -->
  <img src="https://img.shields.io/website/https/proxifly.dev.svg">
  <!-- <img src="https://img.shields.io/github/contributors/proxifly/free-proxy-list.svg"> -->
  <img src="https://img.shields.io/github/last-commit/proxifly/free-proxy-list.svg">
  <img src="https://img.shields.io/github/license/proxifly/free-proxy-list.svg">
  <br>
  <br>
  <a href="https://proxifly.dev">Site</a> | <a href="https://www.npmjs.com/package/proxifly">NPM Module</a> | <a href="https://github.com/proxifly/free-proxy-list">GitHub Repo</a>
</p>

# 🌎 Proxifly's free proxy list
Every 5 minutes, **Proxifly** fetches fresh proxies—including **HTTP**, **HTTPS**, **SOCKS4**, and **SOCKS5** proxies—from around the web.

> Proxifly found **11386** working proxies from **145** countries in the latest update (**Oct 30, 2026, 09:45 AM UTC**).

## 🦄 Features
* ⚡ Extremely fast
* 📝 Validated every 5 minutes
* 📓 Sorted into **HTTP**, **HTTPS**, **SOCKS4**, & **SOCKS5**
* 🌎 Contains proxies from **145 countries**
* 📦 Available in **.json**, **.txt**, **.csv**, & **.yaml** formats
* 🔐 Supports HTTPS connection
* 😊 No duplicates

## 💛 Sponsors

#### <a href="https://github.com/Omega-JS-Stack/omega">OMEGA</a> - The all-in-one JavaScript framework for launching and running brands.
<a href="https://github.com/Omega-JS-Stack/omega"><img src="sponsors/omega.gif" alt="OMEGA" width="100%"></a>

#### <a href="https://github.com/itw-creative-works/workkit">workkit</a> - The issue-pipeline workflow plugin for Claude Code.
<a href="https://github.com/itw-creative-works/workkit"><img src="sponsors/workkit.gif" alt="workkit" width="100%"></a>

## 📦 How do I use the proxies?
You have a few different options for getting the proxies:

<!-- There are so many ways to get our free proxies. -->

<!-- You can just download the whole list as a `.txt` file, or you can even use the **Proxifly NPM module** to fetch proxies into your application programatically.

Proxifly sorts the proxies by protocol and country, but you can also just get the whole unsorted list too. -->

🛑 Please follow the [GitHub Acceptable Use Policy](https://docs.github.com/en/site-policy/acceptable-use-policies/github-acceptable-use-policies) when using this project. You should use these proxies responsibly, without abusing them, and without intent to commit illegal activity.

### 👑 Download from our website: [Free proxy list](https://proxifly.dev/tools/proxy-list)
[![View Free Proxy List](https://flat.badgen.net/badge/label/Download%20from%20Website?icon=chrome&color=4285F4&label=&labelColor=4285F4&scale=1.5)](https://proxifly.dev/tools/proxy-list)



### 💎 Download in our [Free proxy scraper software](https://proxifly.dev/download)
[![Windows](https://flat.badgen.net/badge/label/Windows?icon=windows&color=blue&label=&labelColor=blue&scale=1.5)](https://proxifly.dev/download?download=windows)
[![MacOS](https://flat.badgen.net/badge/label/MacOS?icon=apple&color=black&label=&labelColor=black&scale=1.5)](https://proxifly.dev/download?download=macos)
[![Linux](https://flat.badgen.net/badge/label/Linux?icon=terminal&color=orange&label=&labelColor=orange&scale=1.5)](https://proxifly.dev/download?download=linux)


### 🔗 Direct download links
Click on your preferred file format to get the updated list

|Type|Count|.json|.txt|.csv|.yaml|
|----|-----|-----|----|----|-----|
|All Proxies|11386|[JSON File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/all/data.json)|[Text File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/all/data.txt)|[CSV File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/all/data.csv)|[YAML File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/all/data.yaml)|
|HTTP Proxies|5163|[JSON File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.json)|[Text File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.txt)|[CSV File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.csv)|[YAML File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.yaml)|
|HTTPS Proxies|874|[JSON File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/https/data.json)|[Text File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/https/data.txt)|[CSV File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/https/data.csv)|[YAML File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/https/data.yaml)|
|SOCKS4 Proxies|500|[JSON File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks4/data.json)|[Text File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks4/data.txt)|[CSV File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks4/data.csv)|[YAML File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks4/data.yaml)|
|SOCKS5 Proxies|4849|[JSON File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.json)|[Text File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.txt)|[CSV File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.csv)|[YAML File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.yaml)|
|U.S. proxies ([view more countries](https://github.com/proxifly/free-proxy-list/tree/main/proxies/countries))|2554|[JSON File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/countries/US/data.json)|[Text File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/countries/US/data.txt)|[CSV File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/countries/US/data.csv)|[YAML File](https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/countries/US/data.yaml)|


#### Other sorted proxies
* [🌎 Get proxies by country](https://github.com/proxifly/free-proxy-list/tree/main/proxies/countries)

### 🙌 Use the Proxifly NPM module
Easily fetch updated proxies in your application with the official **Proxifly NPM module**.

```shell
# Run this command to install the module:
npm install proxifly
```


```js
// ESM
import Proxifly from 'proxifly';

// CommonJS
const Proxifly = require('proxifly');
```

```js
const proxifly = new Proxifly({
  // Not required, but having one removes limits (get your key at https://proxifly.dev).
  apiKey: 'your-api-key'
});
```

A `https://ip:port` proxy is one you reach by opening TLS to the proxy itself, which is a different thing than the `https` flag on an `http` proxy (that flag only says the proxy can fetch https targets).

```js
// Fetch proxies with your desired options:
proxifly.getProxy({
  protocol: 'http', // http | https | socks4 | socks5
  anonymity: 'elite', // transparent | anonymous | elite
  country: 'US', // ISO country code
  https: true, // true | false
  format: 'json', // json | text
  quantity: 1, // 1 - 20
})
.then(proxy => {
  console.log('Proxies:', proxy);
})
.catch(e => {
  console.error(e);
})
```


### 🔑 Fetch with cURL
Fetch the latest proxy list with the following command:


#### All proxies
```shell
curl -sL https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/all/data.txt -o all.txt
```


#### HTTP proxies
```shell
curl -sL https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.txt -o http.txt
```


#### SOCKS4 proxies
```shell
curl -sL https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks4/data.txt -o socks4.txt
```


#### SOCKS5 proxies
```shell
curl -sL https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.txt -o socks5.txt
```

#### U.S. proxies ([view more countries](https://github.com/proxifly/free-proxy-list/tree/main/proxies/countries))
```shell
curl -sL https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/countries/US/data.txt -o socks5.txt
```

## ✨ Star history
[![Star History Chart](https://api.star-history.com/chart?repos=proxifly/free-proxy-list&type=date&legend=top-left&sealed_token=NE6Wt65Ig91kaaQrtOqJM1TvwhF5oQKEPv9EyeG3bnNlTgoVQaWHS1E2r8poayVJ327LRGtiLq4hBQUfJEjUr55Z1V1vOdG005ZhjvSCWPupb5HqG8LZCg)](https://www.star-history.com/?repos=proxifly%2Ffree-proxy-list&type=date&legend=top-left)

## 🧸 Contributing
Contributions are welcome, and they are greatly appreciated! Every
little bit helps, and credit will always be given.

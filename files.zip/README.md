# Simple web proxy
1. Install Node.js 18 or newer.
2. In this folder run: `node server.js`
3. Open http://localhost:3000 and enter a site address.

To put it online, upload this folder to a Node host (Render, Railway, Fly.io, etc.) with start command `node server.js`.

Notes
- Blocks requests to private/internal addresses so it can't be used to reach your own network.
- Only does GET requests and rewrites links in HTML pages. Logins, video and JavaScript-heavy sites or games mostly won't work.
- Don't leave it open to the public without adding a password: an open proxy gets abused fast.

// Minimal web proxy. No dependencies. Run: node server.js  (needs Node 18+)
const http=require('http'),https=require('https'),dns=require('dns').promises,net=require('net');
const PORT=process.env.PORT||3000;
const PAGE=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Free Web Proxy</title>
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f0b1e;color:#f3f0ff;font:16px system-ui,sans-serif}
main{width:min(640px,92vw);text-align:center}h1{font-size:34px}h1 b{color:#8c6cff}form{display:flex;gap:8px;margin:24px 0}
input{flex:1;padding:14px 18px;border-radius:999px;border:2px solid transparent;background:#241b45;color:#fff;font-size:16px;outline:none}input:focus{border-color:#6842ff}
button{background:#6842ff;color:#fff;border:0;border-radius:999px;padding:0 26px;font-weight:700;cursor:pointer;font-size:16px}p{color:#9a92c4;font-size:14px}</style></head>
<body><main><h1>🌐 Free Web <b>Proxy</b></h1><form action="/go" method="get"><input name="url" placeholder="Enter a website address, e.g. wikipedia.org" required autofocus><button>Go</button></form>
<p>Browse pages through this server. Don't enter passwords or personal details.</p></main></body></html>`;

const priv=ip=>net.isIPv4(ip)?/^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip):/^(::1?$|f[cd]|fe80)/i.test(ip);

async function go(u,req,res,hops=0){
  let t;try{t=new URL(u)}catch{return res.writeHead(400).end('Bad URL')}
  if(!/^https?:$/.test(t.protocol))return res.writeHead(400).end('Only http and https');
  try{const a=await dns.lookup(t.hostname,{all:true});if(a.some(x=>priv(x.address)))return res.writeHead(403).end('Blocked address')}
  catch{return res.writeHead(502).end('Could not find that site')}
  const lib=t.protocol==='https:'?https:http;
  const p=lib.request(t,{method:'GET',timeout:15000,headers:{
    'user-agent':req.headers['user-agent']||'Mozilla/5.0','accept':req.headers.accept||'*/*','accept-language':req.headers['accept-language']||'en'}},r=>{
    if(r.statusCode>=300&&r.statusCode<400&&r.headers.location&&hops<5){r.resume();return go(new URL(r.headers.location,t).href,req,res,hops+1)}
    const ct=r.headers['content-type']||'';
    const h={'content-type':ct,'x-content-type-options':'nosniff','content-security-policy':'sandbox allow-scripts allow-forms'};
    if(!/text\/html/i.test(ct)){res.writeHead(r.statusCode,h);return r.pipe(res)}
    let b='';r.setEncoding('utf8');r.on('data',c=>b+=c);
    r.on('end',()=>{
      b=b.replace(/(\s(?:href|src|action)=["'])([^"'#][^"']*)/gi,(m,a,v)=>{try{return a+'/go?url='+encodeURIComponent(new URL(v,t).href)}catch{return m}});
      res.writeHead(r.statusCode,h);res.end(b)});
  });
  p.on('error',()=>{if(!res.headersSent)res.writeHead(502);res.end('Fetch failed')});
  p.on('timeout',()=>p.destroy());p.end();
}

http.createServer((req,res)=>{
  const u=new URL(req.url,'http://x');
  if(u.pathname==='/go'){
    let t=(u.searchParams.get('url')||'').trim();if(!t)return res.writeHead(302,{location:'/'}).end();
    if(!/^https?:\/\//i.test(t))t='https://'+t;return go(t,req,res);
  }
  res.writeHead(200,{'content-type':'text/html; charset=utf-8'}).end(PAGE);
}).listen(PORT,()=>console.log('Proxy running on http://localhost:'+PORT));
